#define SEED 8762
#define RUNS 10
#define BINS 100

#define MSG_LEN 256
