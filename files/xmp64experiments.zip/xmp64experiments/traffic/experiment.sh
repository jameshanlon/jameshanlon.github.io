#!/bin/bash

java -cp Traffic/bin traffic.Main -experiment=1
