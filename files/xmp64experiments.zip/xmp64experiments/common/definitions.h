#define XMP64
#define NUM_NODES        64
#define NUM_CORES        4
#define NUM_DIMENSIONS   6
#define OUTER_DIMENSIONS 4
